import numpy as np
import igraph as ig
import cv2 as cv
from sklearn.cluster import KMeans

# for mask, the value:
# 0: background
# 1: foreground
# 2: probable background
# 3: probable foreground

class GMM(object):
    def __init__(self, X, n_components=5):
        self.n_components = n_components
        self.n_samples = np.zeros(self.n_components)
        self.n_features = X.shape[1]
        self.means = np.zeros((self.n_components, self.n_features))
        self.full_cov = np.zeros((self.n_components, self.n_features, self.n_features))
        self.coefficients = np.zeros(self.n_components)
        self.fit(X, KMeans(n_clusters=self.n_components, n_init=1).fit(X).labels_)
        
    def get_component_score(self, X, ci):
        if self.coefficients[ci] > 0:
            multiple = np.einsum('ij,ij->i', (X-self.means[ci]), np.dot(np.linalg.inv(self.full_cov[ci]), (X-self.means[ci]).T).T)
            score = np.exp(-.5 * multiple) / (((2*np.pi)**(1/2))*np.sqrt(np.linalg.det(self.full_cov[ci])))
        else:
            score = np.zeros(X.shape[0])
        return score

    def get_probability(self, X):
        return np.dot(self.coefficients, [self.get_component_score(X, ci) for ci in range(self.n_components)])

    def fit(self, X, labels):
        variance = 0.05
        categories,count = np.unique(labels, return_counts=True)
        self.n_samples[categories] = count
        for ci in categories:
            self.coefficients[ci] = self.n_samples[ci] / np.sum(self.n_samples)
            self.means[ci] = np.mean(X[ci == labels],axis=0)
            if(self.n_samples[ci] <= 1):
                self.full_cov[ci] = 0
            else:
                self.full_cov[ci] = np.cov(X[ci == labels].T)
            det = np.linalg.det(self.full_cov[ci])
            if det <= 0:
                # Adds the noise to avoid singular covariance matrix.
                self.full_cov[ci] += np.eye(self.n_features)*variance
                det = np.linalg.det(self.full_cov[ci])


# this function is used to construct the grabcut graph
def construct_grabcut_graph(image,mask,source_vertex,sink_vertex,fgd_gmm,bgd_gmm,gamma,rows,cols,left_V,upleft_V,up_V,upright_V):
    # get the indices of each type of mask value
    bgd_indices = np.where(mask.reshape(-1) == 0) # background points indices
    fgd_indices = np.where(mask.reshape(-1) == 1) # foreground points indices
    probable_indices = np.where(np.logical_or(mask.reshape(-1) == 2,mask.reshape(-1) == 3)) # probable background/foreground points indices

    edges = []
    gibbs_energy = []
    capa_coef = 10*gamma
    
    # t-links
    edges += zip([source_vertex] * probable_indices[0].size, probable_indices[0])
    edges += zip([sink_vertex] * probable_indices[0].size, probable_indices[0])
    edges += zip([source_vertex] * bgd_indices[0].size, bgd_indices[0])
    edges += zip([sink_vertex] * bgd_indices[0].size, bgd_indices[0])
    edges += zip([source_vertex]*fgd_indices[0].size, fgd_indices[0])
    edges += zip([sink_vertex] * fgd_indices[0].size, fgd_indices[0])

    # n-links
    image_indices = np.arange(rows*cols,dtype=np.uint32).reshape(rows,cols)
    edges += zip(image_indices[:,1:].reshape(-1), image_indices[:,:-1].reshape(-1))
    edges += zip(image_indices[1:,1:].reshape(-1), image_indices[:-1,:-1].reshape(-1))
    edges += zip(image_indices[1:,:].reshape(-1), image_indices[:-1,:].reshape(-1))
    edges += zip(image_indices[1:,:-1].reshape(-1), image_indices[:-1,1:].reshape(-1))

    # add U to Gibbs energy
    D_function_bgd = -np.log(bgd_gmm.get_probability(image.reshape(-1, 3)[probable_indices]))
    D_function_fgd = -np.log(fgd_gmm.get_probability(image.reshape(-1, 3)[probable_indices]))
    gibbs_energy += D_function_bgd.tolist()
    gibbs_energy += D_function_fgd.tolist()
    gibbs_energy += [0]*bgd_indices[0].size    
    gibbs_energy += [capa_coef]*bgd_indices[0].size
    gibbs_energy += [capa_coef]*fgd_indices[0].size    
    gibbs_energy += [0] * fgd_indices[0].size

    # add V to Gibbs energy
    gibbs_energy += left_V.reshape(-1).tolist()
    gibbs_energy += upleft_V.reshape(-1).tolist()
    gibbs_energy += up_V.reshape(-1).tolist()
    gibbs_energy += upright_V.reshape(-1).tolist()

    graph = ig.Graph(cols*rows + 2)
    graph.add_edges(edges)
    return graph,source_vertex,sink_vertex,gibbs_energy


def classify(mask,graph,source_vertex,sink_vertex,gibbs_energy,rows,cols):
    mincut = graph.st_mincut(source_vertex,sink_vertex, gibbs_energy)
    probable_indices = np.where(np.logical_or(mask == 2, mask == 3))
    image_indices = np.arange(rows * cols,dtype=np.uint32).reshape(rows, cols)
    mask[probable_indices] = np.where(np.isin(image_indices[probable_indices], mincut.partition[0]),3,2)
    bgd_indices = np.where(np.logical_or(mask == 0,mask == 2))
    fgd_indices = np.where(np.logical_or(mask == 1,mask == 3))
    return mask,bgd_indices,fgd_indices


def min_x(x1,x2,y1,y2):
	if x1<x2:
		return x1,y1
	else:
		return x2,y2


def GrabCut(filename,foreground=[],background=[], pos1x=1,pos1y=1,pos2x=511,pos2y=511):
    image = cv.imread(filename)
    image = np.asarray(image, dtype=np.float64)
    rows,cols, _ = image.shape
    mask = np.zeros(image.shape[:2], dtype=np.uint8)

    mask[pos1y:pos1y+pos2y, pos1x:pos1x+pos2x] = 3

    for y1,x1,y2,x2 in foreground:
        if x1==x2:
            mask[x1,min(y1,y2):max(y1,y2)+1] = 1
        else:
            k = (y1-y2)/(x1-x2)
            x,y = min_x(x1,x2,y1,y2)
            while True:
                mask[x,y] = 1
                x = x+1
                y = int(round(y+k))
                if x>max(x1,x2):
                    break

    for y1,x1,y2,x2 in background:
        if x1==x2:
                mask[x1,min(y1,y2):max(y1,y2)+1] = 0
        else:
            k = (y1-y2)/(x1-x2)
            x,y = min_x(x1,x2,y1,y2)
            while True:
                mask[x,y] = 0
                x = x+1
                y = int(round(y+k))
                if x>max(x1,x2):
                    break

    bgd_indices = np.where(np.logical_or(mask == 0, mask == 2))
    fgd_indices = np.where(np.logical_or(mask == 1, mask == 3))

    bgd_gmm = GMM(image[bgd_indices])
    fgd_gmm = GMM(image[fgd_indices])
    # the recommend gamma value in the paper
    gamma = 50
    beta = 0

    source_vertex = cols*rows
    sink_vertex = source_vertex + 1

    left_distance = np.square(image[:,1:]-image[:,:-1])
    upleft_distance = np.square(image[1:,1:]-image[:-1,:-1])
    up_distance = np.square(image[1:,:]-image[:-1,:])
    upright_distance = np.square(image[1:,:-1]-image[:-1,1:])

    beta = 1 / (2*(np.sum(left_distance) + np.sum(upleft_distance) + np.sum(up_distance) + np.sum(upright_distance)) / (4*cols*rows - 3*cols - 3*rows+ 2))

    left_V = gamma * np.exp(-beta * np.sum(left_distance, axis=2))
    upleft_V = gamma / (2**(1/2)) * np.exp(-beta * np.sum(upleft_distance, axis=2))
    up_V = gamma * np.exp(-beta * np.sum(up_distance, axis=2))
    upright_V = gamma / (2**(1/2)) * np.exp(-beta * np.sum(upright_distance, axis=2))

    graph,source_vertex,sink_vertex,gibbs_energy = construct_grabcut_graph(image,mask,source_vertex,sink_vertex,fgd_gmm,bgd_gmm,gamma,rows,cols,left_V,upleft_V,up_V,upright_V)
    mask,bgd_indices,fgd_indices = classify(mask,graph,source_vertex,sink_vertex,gibbs_energy,rows,cols)
    mask2 = np.where((mask == 1)+(mask == 3), 255, 0).astype('uint8')
    output = cv.bitwise_and(image, image, mask=mask2)
    cv.imwrite('out.png',output)
    return True

