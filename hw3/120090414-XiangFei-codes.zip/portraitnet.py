import paddle
import paddle.nn as nn
from paddle import ParamAttr


class InvertedResidual(nn.Layer):
    def __init__(self, input_c, output_c, stride, bn_scale):
        super(InvertedResidual, self).__init__()
        self.stride = stride
        self.input_c = input_c
        self.output_c = output_c
        
        self.conv = nn.Sequential(
            # pointwise convolution 
            nn.Conv2D(input_c,input_c*bn_scale,kernel_size=1,stride=1,padding=0,dilation=1,groups=1,weight_attr=ParamAttr(),bias_attr=False),
            nn.BatchNorm(input_c*bn_scale,param_attr=ParamAttr(),bias_attr=ParamAttr()),
            nn.ReLU6(),
            # depthwise convolution
            nn.Conv2D(input_c*bn_scale,input_c*bn_scale,kernel_size=3,stride=stride,padding=1,dilation=1,groups=input_c*bn_scale,weight_attr=ParamAttr(),bias_attr=False),
            nn.BatchNorm(input_c*bn_scale,param_attr=ParamAttr(),bias_attr=ParamAttr()),
            nn.ReLU6(),
            # pointwise-linear
            nn.Conv2D(input_c*bn_scale,output_c,kernel_size=1,stride=1,padding=0,dilation=1,groups=1,weight_attr=ParamAttr(),bias_attr=False),
            nn.BatchNorm(output_c,param_attr=ParamAttr(),bias_attr=ParamAttr())
        )
        
    def forward(self, inputs):
        y = self.conv(inputs)
        if ((self.stride==1) and (self.input_c == self.output_c)):
            y = paddle.add(inputs, y)
        return y


class D_block(nn.Layer):
    def __init__(self,input_c,output_c):
        super(D_block, self).__init__()
        self.input_c = input_c
        self.output_c = output_c

        self.block = nn.Sequential(
            nn.Conv2D(input_c,input_c,kernel_size=3,stride=1,padding=1,groups=input_c,weight_attr=ParamAttr(),bias_attr=False),
            nn.BatchNorm(input_c,param_attr=ParamAttr(),bias_attr=ParamAttr()),
            nn.ReLU(),
            nn.Conv2D(input_c,output_c,kernel_size=1,stride=1,padding=0,groups=1,weight_attr=ParamAttr(),bias_attr=False),
            nn.BatchNorm(output_c,param_attr=ParamAttr(),bias_attr=ParamAttr()),
            nn.ReLU(),
            nn.Conv2D(output_c,output_c,kernel_size=3,stride=1,padding=1,groups=output_c,weight_attr=ParamAttr(),bias_attr=False),
            nn.BatchNorm(output_c,param_attr=ParamAttr(),bias_attr=ParamAttr()),
            nn.ReLU(),
            nn.Conv2D(output_c,output_c,kernel_size=1,stride=1,padding=0,groups=1,weight_attr=ParamAttr(),bias_attr=False),
            nn.BatchNorm(output_c,param_attr=ParamAttr(),bias_attr=ParamAttr())
        )

        self.residual = nn.Sequential(
            nn.Conv2D(input_c,output_c,kernel_size=1,stride=1,padding=0,groups=1,weight_attr=ParamAttr(),bias_attr=False),
            nn.BatchNorm(output_c,param_attr=ParamAttr(),bias_attr=ParamAttr())
        )

        self.relu = nn.ReLU()

    def forward(self, inputs):
        residual = inputs
        output = self.block(inputs)
        if self.input_c != self.output_c:
            residual = self.residual(inputs)
        
        output += residual
        output = self.relu(output)
        return output


class PortraitNet(nn.Layer):
    def __init__(self,n_class=2):
        super(PortraitNet, self).__init__()

        self.e_stage0 = nn.Sequential(
            nn.Conv2D(3,32,kernel_size=3,stride=2,padding=1,groups=1,weight_attr=ParamAttr(),bias_attr=False),
            nn.BatchNorm(32,param_attr=ParamAttr(),bias_attr=ParamAttr()),
            nn.ReLU()
        )
        # 1/2
        self.e_stage1 = InvertedResidual(32,16,1,1)
        # 1/4
        self.e_stage2 = nn.Sequential( 
            InvertedResidual(16,24,2,6),
            InvertedResidual(24,24,1,6)
        )  
        # 1/8
        self.e_stage3 = nn.Sequential( 
            InvertedResidual(24,32,2,6),
            InvertedResidual(32,32,1,6),
            InvertedResidual(32,32,1,6)
        )
        # 1/16
        self.e_stage4 = nn.Sequential( 
            InvertedResidual(32,64,2,6),
            InvertedResidual(64,64,1,6),
            InvertedResidual(64,64,1,6),
            InvertedResidual(64,64,1,6)
        )
        # 1/16
        self.e_stage5 = nn.Sequential( 
            InvertedResidual(64,96,1,6),
            InvertedResidual(96,96,1,6),
            InvertedResidual(96,96,1,6)
        )
        # 1/32
        self.e_stage6 = nn.Sequential( 
            InvertedResidual(96,160,2,6),
            InvertedResidual(160,160,1,6),
            InvertedResidual(160,160,1,6)
        )
        self.e_stage7 = InvertedResidual(160,320,1,6)

        self.deconv1 = nn.Conv2DTranspose(96,96,kernel_size=4,stride=2,padding=1,groups=1,weight_attr=ParamAttr(),bias_attr=False)
        self.deconv2 = nn.Conv2DTranspose(32,32,kernel_size=4,stride=2,padding=1,groups=1,weight_attr=ParamAttr(),bias_attr=False)
        self.deconv3 = nn.Conv2DTranspose(24,24,kernel_size=4,stride=2,padding=1,groups=1,weight_attr=ParamAttr(),bias_attr=False)
        self.deconv4 = nn.Conv2DTranspose(16,16,kernel_size=4,stride=2,padding=1,groups=1,weight_attr=ParamAttr(),bias_attr=False)
        self.deconv5 = nn.Conv2DTranspose(8,8,kernel_size=4,stride=2,padding=1,groups=1,weight_attr=ParamAttr(),bias_attr=False)

        self.d_block1 = D_block(320,96)
        self.d_block2 = D_block(96,32)
        self.d_block3 = D_block(32,24)
        self.d_block4 = D_block(24,16)
        self.d_block5 = D_block(16,8)

        self.pred = nn.Conv2D(8,n_class,kernel_size=3,stride=1,padding=1,groups=1,weight_attr=ParamAttr(),bias_attr=False)
        self.edge = nn.Conv2D(8,n_class,kernel_size=3,stride=1,padding=1,groups=1,weight_attr=ParamAttr(),bias_attr=False)

    def forward(self, inputs):
        feature2  = self.e_stage0(inputs)
        feature2  = self.e_stage1(feature2)
        feature4  = self.e_stage2(feature2)
        feature8  = self.e_stage3(feature4)
        feature16 = self.e_stage4(feature8)
        feature16 = self.e_stage5(feature16)
        feature32 = self.e_stage6(feature16)
        feature32 = self.e_stage7(feature32)
        
        db1 = self.d_block1(feature32)
        up16 = self.deconv1(db1)
        db2 = self.d_block2(feature16+up16)
        up8  = self.deconv2(db2)
        db3 = self.d_block3(feature8+up8)
        up4  = self.deconv3(db3)
        db4 = self.d_block4(feature4+up4)
        up2  = self.deconv4(db4)
        db5 = self.d_block5(up2)
        up1  = self.deconv5(db5)
        
        return self.pred(up1),self.edge(up1)
