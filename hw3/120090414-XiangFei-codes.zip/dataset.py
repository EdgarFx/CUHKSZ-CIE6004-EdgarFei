import os
import numpy as np
import paddle
import cv2
from scipy.ndimage import distance_transform_edt


class dataset(paddle.io.Dataset):
    def __init__(self,path_image,path_label,data_root,img_shape=(224,224),aug=True):
        file_image=open(path_image).readlines()
        file_label=open(path_label).readlines()
        file_image=list(set(file_image))
        file_label=list(set(file_label))
        self.images=[]
        self.masks=[]
        for line in file_image:
            img = line[:-1]
            img=os.path.join(data_root,img)
            self.images.append(img)
        for line in file_label:
            mask = line[:-1]
            mask=os.path.join(data_root,mask)
            self.masks.append(mask)
        self.hflip=RandomHorizontalFlip()
        self.rotation=RandomRotation()
        self.resize=Resize(img_shape)
        self.translate=RandomTranslate()
        self.randhsv=RandomHSV()
        self.randc=RandomContrast()
        self.blur=RandomBlur()
        self.gaussian=RandomNoise()
        self.norm=paddle.vision.transforms.Compose([paddle.vision.transforms.Normalize()])
        self.aug=aug

    def __getitem__(self,idx):
        img=self.images[idx] 
        mask=self.masks[idx]
        img=cv2.imread(img,1)
        if img is None:
            print(img)
        mask=cv2.imread(mask,0)
        mask[mask>1]=1
        if self.aug is False:
            img,mask=self.resize(img,mask)
            img=self.norm(img.transpose([2,0,1]))
            return img,img,mask,mask
        img,mask=self.resize(*self.rotation(*self.hflip(img,mask)))
        # use kl loss
        img_aug=self.randc(self.randhsv(img))
        img=self.norm(img.transpose([2,0,1]))
        img_aug=self.norm(img_aug.transpose([2,0,1]))
        # use edge loss
        edge=mask_to_binary_edge(mask,4,2)
        return img,img_aug,mask.astype('int64'),edge.astype('int64')

    def __len__(self):
        return len(self.images)

# the following part is copied from paddleseg
def mask_to_one_hot(mask, num_classes):
    # Convert a mask (H, W) to onehot (K, H, W)
    one_hot_mask = [mask == i for i in range(num_classes)]
    one_hot_mask = np.array(one_hot_mask).astype(np.uint8)
    return one_hot_mask


def one_hot_to_binary_edge(mask, radius):
    # Convert a onehot mask (K, H, W) to a edge mask.
    # the radius of edge should greater than or equal to 1
    num_classes = mask.shape[0]
    edge = np.zeros(mask.shape[1:])
    # pad borders
    mask = np.pad(mask,((0,0),(1,1),(1,1)), mode='constant', constant_values=0)
    for i in range(num_classes):
        dist = distance_transform_edt(mask[i, :]) + distance_transform_edt(1.0 - mask[i, :])
        dist = dist[1:-1, 1:-1]
        dist[dist > radius] = 0
        edge += dist

    edge = np.expand_dims(edge, axis=0)
    edge = (edge>0).astype(np.uint8)
    return edge


def mask_to_binary_edge(mask, radius, num_classes):
    #Convert a segmentic segmentation mask (H, W) to a binary edge mask(H, W).
    mask = mask.squeeze()
    onehot = mask_to_one_hot(mask, num_classes)
    edge = one_hot_to_binary_edge(onehot, radius)
    return edge


# the following is used for data augmentation. Since it is not the core implementation of the paper and generally when we reproduce papers
# we can used some code from the previous work, so I write this part based on an open source code provided by paddle
class RandomHorizontalFlip():
    def __init__(self,prob=0.5):
        self.prob=prob
    
    def __call__(self,img,mask):
        if np.random.uniform(0,1)<self.prob:
            img=cv2.flip(img,1)
            mask=cv2.flip(mask,1)
        return img,mask

class RandomRotation():
    def __init__(self,max_rotation=45,resize_range=(0.5,1.5)):
        self.max_rotation=max_rotation
        self.resize_range=resize_range
    
    def __call__(self, img, mask):
        h,w=img.shape[:2]
        rot=np.random.uniform(-self.max_rotation,self.max_rotation)
        resize=np.random.uniform(*self.resize_range)
        M=cv2.getRotationMatrix2D((h//2,w//2), rot, resize)
        img=cv2.warpAffine(img,M,(w,h))
        mask=cv2.warpAffine(mask,M,(w,h))
        return img,mask

class Resize():
    def __init__(self,shape):
        self.shape=shape

    def __call__(self,img,mask):
        img=cv2.resize(img,self.shape)
        mask=cv2.resize(mask,self.shape,interpolation=cv2.INTER_NEAREST)
        return img,mask


class RandomHSV():
    def __init__(self,
                hue_prob=0.5,hue_range=(0.4,1.7),
                saturation_prob=0.5,saturation_range=(0.4,1.7),
                value_prob=0.5,value_range=(0.4,1.7)
                ):
        self.hue_prob=hue_prob
        self.hue_range=hue_range
        self.saturation_prob=saturation_prob
        self.saturation_range=saturation_range
        self.value_prob=value_prob
        self.value_range=value_range

    def __call__(self, img):
        img=cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
        if np.random.uniform()<self.hue_prob:
            h=np.random.uniform(self.hue_range[0],self.hue_range[1])
            img[:,:,0]=img[:,:,0]*h
            img[:,:,0]=np.clip(img[:,:,0],0,179)
        if np.random.uniform()<self.saturation_prob:
            s=np.random.uniform(self.saturation_range[0],self.saturation_range[1])
            img[:,:,1]=img[:,:,1]*s
        if np.random.uniform()<self.value_prob:
            v=np.random.uniform(self.value_range[0],self.value_range[1])
            img[:,:,2]=img[:,:,2]*v
        img=np.clip(img,0,255)
        img=cv2.cvtColor(img,cv2.COLOR_HSV2BGR)
        return img

class RandomContrast():
    def __init__(self,prob=0.5,randrange=(0.6,1.5)):
        self.prob=prob
        self.range=randrange

    def __call__(self,img):
        if np.random.uniform()<self.prob:
            c=np.random.uniform(*self.range)
            for i in range(3):
                maxc,minc=np.max(img[:,:,i]),np.min(img[:,:,i])
                img[:,:,i]=(img[:,:,i]-minc)*c+(128-(maxc-minc)*c/2)
            img=np.clip(img,0,255)
        return img

class RandomTranslate():
    def __init__(self,randrange=0.25):
        self.range=randrange

    def __call__(self,img,label):
        c1=np.random.uniform(-self.range,self.range)
        c2=np.random.uniform(-self.range,self.range)
        M = np.array([[1,0,c1*img.shape[1]],[0,1,c2*img.shape[0]]])
        img = cv2.warpAffine(img,M,(img.shape[1],img.shape[0]))
        label = cv2.warpAffine(label,M,(label.shape[1],label.shape[0]))
        return img,label

class RandomBlur():
    def __init__(self,prob=0.5):
        self.prob=prob

    def __call__(self,img):
        if np.random.uniform()<self.prob:
            return img
        ks=np.random.randint(3, 10)
        img = cv2.blur(img, (ks, ks))
        return img

class RandomNoise():
    def __init__(self,prob=0.5):
        self.prob=prob

    def __call__(self,img):
        if np.random.uniform()<self.prob:
            return img
        img = cv2.GaussianBlur(img, (0,0), 10)
        return img