from paddle.nn import KLDivLoss
import paddle.nn.functional as F 
from tqdm import tqdm
import paddle
import argparse
import paddle.nn as nn

from dataset import dataset
from portraitnet import PortraitNet
from utils import ACC,MIOU,Loss

class FocalLoss(nn.Layer):
    def __init__(self, alpha=[1.]*2, gamma=2.0, ignore_index=255,smooth_rate=0,online_reweighting=False):
        super(FocalLoss, self).__init__()
        self.ignore_index = ignore_index
        self.EPS = 1e-8
        if isinstance(alpha,list):
            self.alpha=paddle.to_tensor(alpha)
        self.alpha=paddle.reshape(self.alpha,(1,1,1,2))
        self.gamma=gamma
        self.smooth_rate=smooth_rate

    def forward(self, logit, label):
        label_one_hot=nn.functional.one_hot(label,2)
        p=nn.functional.softmax(logit)*(1-2*self.EPS)+self.EPS
        loss=-paddle.pow(1-p,self.gamma)*paddle.log(p)
        loss=paddle.max(loss*label_one_hot,axis=-1)
        return paddle.mean(loss)


def pharse_args():
    parser=argparse.ArgumentParser()
    parser.add_argument('--data_root', type=str, default='EG1800/')
    parser.add_argument('--batch_size', type=int, default=64)
    parser.add_argument('--epoch', type=int, default=1)
    parser.add_argument('--lr', type=float, default=0.01)
    parser.add_argument('--num_workers', type=int, default=1)
    parser.add_argument('--log_iter', type=int, default=10)
    return parser.parse_args()


def test(args,model=None):
    datas=dataset('%s/test_images.txt'%args.data_root,'%s/test_labels.txt'%args.data_root,args.data_root,aug=False)
    loader=paddle.io.DataLoader(datas,batch_size=args.batch_size,drop_last=False,shuffle=False)
    
    if model is None:
        model=PortraitNet(edge=True)
        model.set_state_dict(paddle.load(args.model_path))
    model.eval()

    acc=ACC()
    miou=MIOU()

    pbar=tqdm(loader)
    pbar.set_description('eval')
    for data in pbar:
        img,img_aug,mask,edge_mask=data
        output,_=model(img)
        output=output.transpose([0,2,3,1])
        acc(output,mask)
        miou(output,mask)

        if (pbar.last_print_n+1)%args.log_iter==0:
            print('iter %d  acc: %.5f, miou: %.5f '%(pbar.last_print_n,acc.part_metric.new_step(),miou.part_metric.new_step()))
            
    print('eval: acc: %.5f, miou: %.5f '%(acc.new_step(),miou.new_step()))
    return

def train(args):
    datas=dataset('%s/train_images.txt'%args.data_root,'%s/train_labels.txt'%args.data_root,args.data_root)
    loader=paddle.io.DataLoader(datas,batch_size=args.batch_size,drop_last=True,shuffle=True)
    
    model=PortraitNet()
    loss_func=nn.CrossEntropyLoss()
    edge_func=FocalLoss()
    kl_func=KLDivLoss()

    lr=args.lr
    optimizer=paddle.optimizer.AdamW(learning_rate=args.lr,parameters=model.parameters(),weight_decay=1e-6)
    lossm=Loss()
    acc=ACC()
    miou=MIOU()
    
    for epoch in range(args.epoch):
        pbar=tqdm(loader)
        pbar.set_description("epoch %d/%d:"%(epoch+1,args.epoch))
        lr=(1-(epoch/args.epoch)**0.95)*args.lr
        optimizer.set_lr(lr)
        model.train()
        
        for data in pbar:
            img,img_aug,mask,edge_mask=data
            edge_mask=paddle.unsqueeze(edge_mask,1)
            ouput_aug=model(img_aug)
            output=model(img)
            # consider the edge loss
            output,edge=output
            output=output.transpose([0,2,3,1])
            edge=edge.transpose([0,2,3,1])
            loss=loss_func(output,mask)+0.3*edge_func(edge,edge_mask)
            # consider the kl loss
            loss=loss+loss_func(ouput_aug[0].transpose([0,2,3,1]),mask)+2*kl_func(F.log_softmax(ouput_aug[0].transpose([0,2,3,1])),F.softmax(output))
            optimizer.clear_grad()
            loss.backward()
            optimizer.step()
            
            lossm(loss,mask)
            acc(output,mask)
            miou(output,mask)

            if (pbar.last_print_n+1)%args.log_iter==0:
                print('iter %d loss:%.5f, acc: %.5f, miou: %.5f '%(pbar.last_print_n,lossm.part_metric.new_step(),acc.part_metric.new_step(),miou.part_metric.new_step()))
            
        print('epoch %d loss:%.5f, acc: %.5f, miou: %.5f '%(epoch,lossm.new_step(),acc.new_step(),miou.new_step()))
        test(args,model)
        paddle.save(model.state_dict(),'output/model_%d.pdparams'%epoch)



if __name__ =='__main__':
    args=pharse_args()
    train(args)